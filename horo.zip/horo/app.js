/* Horo — birth chart for the Solana trenches. Entertainment only. */
(() => {
'use strict';
const $ = id => document.getElementById(id);
const SIGNS = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];

/* ---------- Stars ---------- */
(function stars(){
  const c = $('stars'), x = c.getContext('2d');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let pts = [];
  function size(){
    c.width = innerWidth * devicePixelRatio; c.height = innerHeight * devicePixelRatio;
    const n = Math.min(220, Math.floor(innerWidth * innerHeight / 6000));
    const cols = ['#ffffff','#39ff14','#a855f7','#ffc94a'];
    pts = Array.from({length:n},()=>({x:Math.random(),y:Math.random(),r:Math.random()*1.4+.3,p:Math.random()*6.28,c:cols[Math.random()*8<1?1+(Math.random()*3|0):0]}));
  }
  function draw(t){
    x.clearRect(0,0,c.width,c.height);
    for(const s of pts){
      x.globalAlpha = reduce ? .7 : .35 + .65*Math.abs(Math.sin(t/1400 + s.p));
      x.fillStyle = s.c;
      x.beginPath(); x.arc(s.x*c.width, s.y*c.height, s.r*devicePixelRatio, 0, 6.283); x.fill();
    }
    if(!reduce) requestAnimationFrame(draw);
  }
  size(); draw(0);
  addEventListener('resize', () => { size(); if(reduce) draw(0); });
})();

/* ---------- Geocoding (Nominatim) ---------- */
let picked = null;           // {lat, lon, name}
let suggestTimer = null, lastQuery = '', activeIdx = -1, results = [];
const placeEl = $('place'), listEl = $('suggest'), hintEl = $('placeHint');

const flat = t => t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
function localCities(q, limit){
  const k = flat(q); if(!k) return [];
  const hit = (window.CITIES || []).filter(c => flat(c[0]).includes(k));
  hit.sort((a, b) => (flat(a[0]).startsWith(k) ? 0 : 1) - (flat(b[0]).startsWith(k) ? 0 : 1));
  return hit.slice(0, limit).map(c => ({display_name: c[0], lat: c[1], lon: c[2], tz: c[3], local: true}));
}
async function geocode(q, limit = 5){
  try{
    const u = 'https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=0&limit=' + limit + '&q=' + encodeURIComponent(q);
    const r = await fetch(u, {headers:{'Accept':'application/json'}});
    if(!r.ok) throw new Error('nominatim ' + r.status);
    const res = await r.json();
    if(res.length) return res;
  }catch(_){}
  return localCities(q, limit);            // offline / blocked / no match: built-in city list
}
function closeList(){ listEl.hidden = true; placeEl.setAttribute('aria-expanded','false'); activeIdx = -1; }
function choose(i){
  const p = results[i]; if(!p) return;
  picked = {lat:+p.lat, lon:+p.lon, name:p.display_name, tz:p.tz || null};
  placeEl.value = p.display_name;
  hintEl.textContent = 'Locked: ' + (+p.lat).toFixed(3) + ', ' + (+p.lon).toFixed(3);
  hintEl.className = 'note ok';
  closeList();
}
function renderList(){
  listEl.innerHTML = '';
  results.forEach((p,i) => {
    const li = document.createElement('li');
    li.role = 'option'; li.textContent = p.display_name;
    li.addEventListener('mousedown', e => { e.preventDefault(); choose(i); });
    li.addEventListener('touchstart', e => { e.preventDefault(); choose(i); }, {passive:false});
    listEl.appendChild(li);
  });
  listEl.hidden = !results.length;
  placeEl.setAttribute('aria-expanded', String(!!results.length));
}
placeEl.addEventListener('input', () => {
  picked = null; hintEl.textContent = ''; hintEl.className = 'note';
  clearTimeout(suggestTimer);
  const q = placeEl.value.trim();
  if(q.length < 3){ closeList(); return; }
  suggestTimer = setTimeout(async () => {       // debounce: Nominatim allows ~1 req/sec
    lastQuery = q;
    try{
      const res = await geocode(q);
      if(q !== lastQuery) return;
      results = res; renderList();
      if(!res.length){ hintEl.textContent = 'No match yet. Try city + country.'; }
    }catch(e){ hintEl.textContent = 'Place search is down. Try again in a sec.'; }
  }, 600);
});
placeEl.addEventListener('keydown', e => {
  if(listEl.hidden) return;
  const items = [...listEl.children];
  if(e.key === 'ArrowDown'){ e.preventDefault(); activeIdx = (activeIdx+1) % items.length; }
  else if(e.key === 'ArrowUp'){ e.preventDefault(); activeIdx = (activeIdx-1+items.length) % items.length; }
  else if(e.key === 'Enter' && activeIdx >= 0){ e.preventDefault(); choose(activeIdx); return; }
  else if(e.key === 'Escape'){ closeList(); return; }
  else return;
  items.forEach((li,i) => li.setAttribute('aria-selected', String(i === activeIdx)));
});
placeEl.addEventListener('blur', () => setTimeout(closeList, 150));

/* ---------- Date selects ---------- */
const dayEl = $('day'), monEl = $('month'), yearEl = $('year');
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const opt = (v, t) => { const o = document.createElement('option'); o.value = v; o.textContent = t; return o; };
function fillDays(){
  const keep = dayEl.value, m = +monEl.value, y = +yearEl.value || 2000;
  const n = m ? new Date(y, m, 0).getDate() : 31;
  dayEl.innerHTML = ''; dayEl.appendChild(opt('', 'Day'));
  for(let d = 1; d <= n; d++) dayEl.appendChild(opt(d, d));
  if(keep && +keep <= n) dayEl.value = keep;
}
(function initDate(){
  monEl.appendChild(opt('', 'Month')); MONTHS.forEach((n, i) => monEl.appendChild(opt(i+1, n)));
  yearEl.appendChild(opt('', 'Year'));
  for(let y = new Date().getFullYear(); y >= 1930; y--) yearEl.appendChild(opt(y, y));
  fillDays();
  monEl.addEventListener('change', fillDays); yearEl.addEventListener('change', fillDays);
})();
function setDate(Y, M, D){ yearEl.value = Y; monEl.value = M; fillDays(); dayEl.value = D; }

/* ---------- Unknown time ---------- */
$('unknown').addEventListener('change', e => {
  $('time').disabled = e.target.checked;
  if(e.target.checked) $('time').value = '12:00';
  $('timeNote').hidden = !e.target.checked;
});

/* ---------- Natal chart ---------- */
/* The chart is computed locally (ephemeris.js), so it works for any date and place and needs no API.
   Flip USE_COSMYDAY to true to try the CosmyDay API for Sun/Moon/Rising first; any failure falls back to local. */
const USE_COSMYDAY = false;
const NATAL_URL = 'https://api.cosmyday.com/natal';
function zoneFor(lat, lon){
  try{ if(typeof window.tzlookup === 'function') return window.tzlookup(lat, lon); }catch(_){}
  return null;
}
function buildChart(body, place){
  const tz = place.tz || zoneFor(body.lat, body.lon);
  const res = Astro.natalChart({year:body.year, month:body.month, day:body.day, hour:body.hour, minute:body.minute, lat:body.lat, lon:body.lon, tz});
  return res;
}
async function tryCosmyDay(body){
  const r = await fetch(NATAL_URL, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
  if(!r.ok) throw new Error('natal ' + r.status);
  return parseChart(await r.json());
}
const norm = s => String(s||'').toLowerCase().replace(/[^a-z]/g,'');
function toSign(v){
  if(v == null) return null;
  if(typeof v === 'object') return toSign(v.sign ?? v.name ?? v.sign_name ?? v.zodiac);
  if(typeof v === 'number') return SIGNS[((Math.floor(v/30)%12)+12)%12] || null;
  const n = norm(v);
  return SIGNS.find(s => norm(s) === n) || SIGNS.find(s => n.length >= 3 && norm(s).startsWith(n.slice(0,3))) || null;
}
function parseChart(data){
  const found = {};
  const want = {sun:'sun',moon:'moon',ascendant:'rising',asc:'rising',rising:'rising',risingsign:'rising',ac:'rising'};
  (function walk(o, depth){
    if(!o || typeof o !== 'object' || depth > 6) return;
    if(Array.isArray(o)){ o.forEach(v => walk(v, depth+1)); return; }
    const nm = norm(o.name ?? o.planet ?? o.body ?? o.id ?? o.key ?? o.point);
    if(nm && want[nm] && !found[want[nm]]){ const sg = toSign(o.sign ?? o.sign_name ?? o.zodiac ?? o.longitude ?? o.lon); if(sg) found[want[nm]] = sg; }
    for(const [k,v] of Object.entries(o)){
      const w = want[norm(k)];
      if(w && !found[w]){ const sg = toSign(v); if(sg) found[w] = sg; }
      walk(v, depth+1);
    }
  })(data, 0);
  return found;
}
const fmtSign = p => p ? p.sign + (p.rx ? ' Rx' : '') : '—';

/* ---------- Reading ---------- */
function hash(s){ let h = 2166136261; for(const c of s){ h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
function rng(seed){ let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const wc = s => s.trim().split(/\s+/).filter(Boolean).length;
function localReading(facts, seedStr, variant){
  return {text: Reader.compose(facts, variant, hash(seedStr)), rating: facts.rating};
}
function buildOutput(text, rating){ return text + '\nRating: ' + rating + '/10'; }

/* ---------- Reading: LLM if available, else fallback ---------- */
function validReading(out){
  if(typeof out !== 'string') return null;
  const m = out.trim().match(/^([\s\S]*?)\s*\n?\s*Rating:\s*(\d{1,2})\/10\s*$/);
  if(!m) return null;
  const text = m[1].trim().replace(/\s*\n+\s*/g,' ');
  const n = wc(text), rating = +m[2];
  if(n < 90 || n > 110 || rating < 1 || rating > 10) return null;
  if(/^\s*([-*•]|\d+\.)\s/m.test(m[1]) || /revving/i.test(text)) return null;
  return {text, rating};
}
const AI_RULES = `You are Horo: a human astrologer who also lives in the Solana trenches. Write the daily reading for one person from the fact sheet below.
Rules: ONE continuous paragraph of 90 to 110 words, no lists, no headings, no line breaks. Sound like a real astrologer talking to a friend, not a template or an astrology app. Use the actual placements and today's transits from the fact sheet, never invent any. Say how today's Moon and the strongest transit affect their trading mood. Clearly say: whether to gamble a little on new pairs or size into established coins that already have life; whether to play bigger or smaller sizes; trade vs devving (devving means launching a coin on Pump.fun or similar); stay in the trenches or sit out. Follow the verdict in the fact sheet. No financial advice, no specific coins, no guarantees, never say "revving". Then on a new line write exactly: Rating: X/10 using the rating in the fact sheet. Output nothing else.`;
async function aiViaSample(sheet, variant){
  if(!window.claude || typeof window.claude.use !== 'function') return null;
  const sample = await window.claude.use('sample'); if(!sample) return null;
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 40000);
  try{
    const r = await sample(AI_RULES + '\n\nFACT SHEET:\n' + sheet + '\n\n(Variation ' + variant + ': phrase it freshly.)', {signal: ctl.signal, cache: false, modelTier: 'quick'});
    return r && r.text;
  } finally { clearTimeout(timer); }
}
async function getReading(facts, meta, variant){
  const sheet = Reader.factSheet(facts);
  const tries = [
    () => aiViaSample(sheet, variant),
    async () => {
      const r = await fetch('/api/reading', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({sheet, variant})});
      if(!r.ok) return null; return (await r.json()).reading;
    }
  ];
  for(const t of tries){
    try{
      const v = validReading(await t());
      if(v){ v.rating = facts.rating; return {...v, source:'ai'}; }
    }catch(_){}
  }
  return {...localReading(facts, meta.seed, variant), source:'local'};
}

/* ---------- UI flow ---------- */
let current = null;   // {chart, meta}
let variant = 0, lastOut = '';
const show = (el, on) => { el.hidden = !on; };
function setError(msg){ $('error').textContent = msg || ''; show($('error'), !!msg); }
function busy(on, text){
  $('go').disabled = on;
  show($('loading'), on); if(text) $('loadText').textContent = text;
}
/* ---------- Shareable card (canvas -> image) ---------- */
function drawCard(chart, meta, res, variant){
  const W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const x = cv.getContext('2d'), r = rng(hash(meta.seed + '|card|' + variant));
  const MONO = 'ui-monospace,"SF Mono","JetBrains Mono",Menlo,Consolas,monospace';
  const font = (px, w = 700) => { x.font = w + ' ' + px + 'px ' + MONO; };
  const spacing = v => { if('letterSpacing' in x) x.letterSpacing = v; };
  const glow = (col, b) => { x.shadowColor = col; x.shadowBlur = b; };
  const GREEN = '#39ff14', PURPLE = '#a855f7', GOLD = '#ffc94a';

  x.fillStyle = '#000'; x.fillRect(0, 0, W, H);
  let g = x.createRadialGradient(W*.85, H*.1, 0, W*.85, H*.1, 760); g.addColorStop(0,'rgba(168,85,247,.38)'); g.addColorStop(1,'rgba(168,85,247,0)');
  x.fillStyle = g; x.fillRect(0, 0, W, H);
  g = x.createRadialGradient(W*.08, H*.98, 0, W*.08, H*.98, 700); g.addColorStop(0,'rgba(57,255,20,.24)'); g.addColorStop(1,'rgba(57,255,20,0)');
  x.fillStyle = g; x.fillRect(0, 0, W, H);

  const cols = ['#ffffff','#ffffff','#ffffff',GREEN,PURPLE,GOLD];
  for(let i = 0; i < 190; i++){
    x.globalAlpha = .25 + r()*.75; x.fillStyle = cols[Math.floor(r()*cols.length)];
    x.beginPath(); x.arc(r()*W, r()*H, .6 + r()*2, 0, 6.283); x.fill();
  }
  x.globalAlpha = 1;

  // ground glow: the trenches
  g = x.createLinearGradient(0, H-260, 0, H); g.addColorStop(0,'rgba(57,255,20,0)'); g.addColorStop(1,'rgba(57,255,20,.14)');
  x.fillStyle = g; x.fillRect(0, H-260, W, 260);
  x.strokeStyle = 'rgba(168,85,247,.12)'; x.lineWidth = 1;
  for(let gx = 0; gx < W; gx += 54){ x.beginPath(); x.moveTo(gx, H-260); x.lineTo(gx, H); x.stroke(); }

  // header
  x.textBaseline = 'alphabetic'; x.textAlign = 'left';
  font(50); spacing('6px'); glow(GREEN, 24); x.fillStyle = GREEN; x.fillText('HORO', 70, 100); glow('transparent', 0);
  font(24, 600); spacing('2px'); x.textAlign = 'right'; x.fillStyle = GOLD;
  x.fillText(new Date().toLocaleDateString('en-GB', {weekday:'short', day:'2-digit', month:'short', year:'numeric'}).replace(/,/g,'').toUpperCase(), W-70, 98);
  x.strokeStyle = 'rgba(168,85,247,.5)'; x.beginPath(); x.moveTo(70, 122); x.lineTo(W-70, 122); x.stroke();

  // orbit art
  const cx = W/2, cy = 310;
  x.lineWidth = 2;
  [[80,GOLD],[140,PURPLE],[200,GREEN]].forEach(([rad, col], i) => {
    x.strokeStyle = col; x.globalAlpha = .45; x.beginPath(); x.ellipse(cx, cy, rad*1.55, rad, 0, 0, 6.283); x.stroke(); x.globalAlpha = 1;
    const a = r()*6.283; glow(col, 20); x.fillStyle = col;
    x.beginPath(); x.arc(cx + Math.cos(a)*rad*1.55, cy + Math.sin(a)*rad, 9 - i*1.5, 0, 6.283); x.fill(); glow('transparent', 0);
  });
  [[150,300,'$GM',GOLD],[935,215,'$RX',PURPLE],[905,430,'$DEV',GREEN]].forEach(([px,py,t,col]) => {
    x.globalAlpha = .9; glow(col, 26); x.fillStyle = col; x.beginPath(); x.arc(px, py, 38, 0, 6.283); x.fill(); glow('transparent', 0);
    x.globalAlpha = 1; x.fillStyle = '#000'; font(17); spacing('0px'); x.textAlign = 'center'; x.fillText(t, px, py + 6);
  });
  x.textAlign = 'center'; font(26, 600); spacing('4px'); x.fillStyle = GOLD; x.fillText('24H', cx, cy - 6);
  font(20, 600); spacing('3px'); x.fillStyle = '#e9ffe4'; x.fillText('FORECAST', cx, cy + 26);

  // big three
  [['SUN', chart.sun], ['MOON', chart.moon], ['RISING', chart.rising]].forEach(([lab, p], i) => {
    const px = 180 + i*360;
    font(22, 600); spacing('5px'); x.fillStyle = PURPLE; x.fillText(lab, px, 580);
    font(38); spacing('0px'); glow(GOLD, 14); x.fillStyle = GOLD; x.fillText(fmtSign(p), px, 628); glow('transparent', 0);
  });
  x.strokeStyle = 'rgba(168,85,247,.5)'; x.beginPath(); x.moveTo(70, 668); x.lineTo(W-70, 668); x.stroke();

  // reading, auto-fit
  x.textAlign = 'left'; spacing('0px');
  const maxW = W - 140, top = 720, bottom = 1170;
  let size = 34, lines = [];
  for(; size >= 22; size--){
    font(size, 500); lines = []; let line = '';
    for(const w of res.text.split(/\s+/)){
      const t = line ? line + ' ' + w : w;
      if(x.measureText(t).width > maxW){ lines.push(line); line = w; } else line = t;
    }
    lines.push(line);
    if(lines.length * size * 1.45 <= bottom - top) break;
  }
  font(size, 500); x.fillStyle = '#e9ffe4';
  lines.forEach((l, i) => x.fillText(l, 70, top + size + i*size*1.45));

  // rating
  font(54); glow(GREEN, 22); x.fillStyle = GREEN; x.fillText('Rating: ' + res.rating + '/10', 70, 1232); glow('transparent', 0);
  for(let i = 0; i < 10; i++){
    const on = i < res.rating; x.fillStyle = on ? GREEN : 'rgba(255,255,255,.12)';
    if(on) glow(GREEN, 10); x.fillRect(70 + i*94, 1256, 82, 14); glow('transparent', 0);
  }

  // footer
  font(19, 500); spacing('1px'); x.fillStyle = '#8d9a8a'; x.textAlign = 'center';
  x.fillText((meta.unknownTime ? 'Birth time unknown: Moon and Rising approximate  ·  ' : '') + 'Entertainment only. Not financial advice.', W/2, 1316);
  return cv;
}

function renderResult(res){
  const cv = drawCard(current.chart, current.meta, res, variant);
  const img = $('cardImg'); img.src = cv.toDataURL('image/png'); img.alt = 'Horo daily reading: ' + res.text + ' Rating: ' + res.rating + '/10';
  $('source').textContent = 'Entertainment only. Not financial advice.' + (current.meta.tzApprox ? ' Time zone was estimated from longitude, so Rising may be off.' : '');
  lastOut = buildOutput(res.text, res.rating);
  document.body.classList.add('viewing');
  show($('result'), true);
  scrollTo({top:0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
}

async function run(input){
  setError(''); show($('result'), false); busy(true, 'Casting your chart…');
  try{
    const res = buildChart(input.body, input.place);
    const chart = res.chart;
    if(USE_COSMYDAY){
      try{ const c = await tryCosmyDay(input.body); for(const k of ['sun','moon','rising']) if(c[k]) chart[k] = {...chart[k], sign:c[k]}; }catch(_){}
    }
    const facts = Astro.analyze(chart, Date.now(), {unknownTime: input.unknownTime});
    current = {chart, facts, meta:{unknownTime:input.unknownTime, tzApprox:res.tzApprox, seed:JSON.stringify(input.body) + new Date().toDateString()}};
    variant = 0;
    $('loadText').textContent = 'Reading the trenches…';
    renderResult(await getReading(facts, current.meta, variant));
  }catch(e){ console.error(e); setError('Could not build that chart. Check the date, time and place and try again.'); }
  finally{ busy(false); }
}

$('form').addEventListener('submit', async e => {
  e.preventDefault();
  const unknown = $('unknown').checked;
  const t = unknown ? '12:00' : $('time').value;
  if(!dayEl.value || !monEl.value || !yearEl.value){ return setError('Pick your birth day, month and year.'); }
  if(!t){ return setError('Add your birth time, or tick "I don\'t know my birth time".'); }
  if(!placeEl.value.trim()){ return setError('Add your birth place.'); }
  setError('');
  if(!picked){                               // typed but never picked: use the top match
    busy(true, 'Finding your birth place…');
    try{
      const res = await geocode(placeEl.value.trim(), 1);
      if(!res.length){ busy(false); return setError('Could not find that place. Try "City, Country".'); }
      results = res; choose(0);
    }catch(err){ busy(false); return setError(err.message || 'Place search failed.'); }
  }
  const Y = +yearEl.value, M = +monEl.value, D = +dayEl.value, [h,m] = t.split(':').map(Number);
  run({unknownTime:unknown, place:picked, body:{year:Y, month:M, day:D, hour:h, minute:m, lat:picked.lat, lon:picked.lon}});
});

$('download').addEventListener('click', () => {
  const a = document.createElement('a'); a.href = $('cardImg').src; a.download = 'horo.png';
  document.body.appendChild(a); a.click(); a.remove();
});
$('copy').addEventListener('click', async () => {
  const btn = $('copy'), done = () => { const o = btn.textContent; btn.textContent = 'Copied'; setTimeout(() => btn.textContent = o, 1500); };
  try{ await navigator.clipboard.writeText(lastOut); done(); }
  catch(_){
    const ta = document.createElement('textarea'); ta.value = lastOut; ta.style.cssText = 'position:fixed;opacity:0';
    document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); done(); }catch(e){ setError('Copy failed. Select the text manually.'); }
    ta.remove();
  }
});

})();
