/* Horo reader: turns real chart + transit facts into a human-sounding 90-110 word reading.
   Used as the local writer and as the fact sheet handed to the LLM. */
(function (root) {
'use strict';
const wc = s => s.trim().split(/\s+/).filter(Boolean).length;
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const P = {sun:'Sun', moon:'Moon', mercury:'Mercury', venus:'Venus', mars:'Mars', jupiter:'Jupiter', saturn:'Saturn', uranus:'Uranus', neptune:'Neptune', rising:'Rising'};

const SUN_STYLE = {Aries:'jumps in first and thinks after', Taurus:'holds bags stubbornly and hates being rushed', Gemini:'scans everything and rotates fast',
  Cancer:'trades on gut feel and guards capital', Leo:'wants the big, loud play', Virgo:'checks every wallet and detail',
  Libra:'hates being the last one in', Scorpio:'smells traps early and goes heavy when sure', Sagittarius:'always believes in the next big thing',
  Capricorn:'plays long and respects risk', Aquarius:'likes the weird, early narrative', Pisces:'follows vibes toward a moonshot'};
const MOON_FEEL = {fire:'reacts fast', earth:'wants proof first', air:'wants the group chat', water:'feels every candle'};
const MOOD = {fire:'hot and fast', earth:'slow and practical', air:'chatty and scattered', water:'moody and intuitive'};
const VERB = {conjunction:'sits right on', sextile:'sextiles', square:'squares', trine:'trines', opposition:'opposes'};

const EFFECT = {
  moon:{easy:'your gut and the screen finally agree, so reads come cleaner', hard:'nerves run ahead of the chart and every wick feels personal', merge:'feelings get amplified, which helps if you listen and hurts if you chase'},
  sun:{easy:'confidence runs steady without needing a win to prove it', hard:'ego wants a win, which is exactly when sloppy entries happen', merge:'the spotlight is on you, so you will feel surer than you should'},
  mercury:{easy:'timing and details come cleanly and you spot what others skim past', hard:'you can misread a chart or a tweet, so double check before clicking', merge:'your mind runs fast and loud, great for scanning and bad for patience'},
  venus:{easy:'your taste is sharp and you can feel which community is real', hard:'you may overpay for a pretty chart, so do not fall for a ticker', merge:'attraction runs strong and you will fall for a coin quickly'},
  mars:{easy:'nerve and energy are available, so you can act cleanly', hard:'impatience spikes and ape-ins come too fast', merge:'adrenaline spikes, good for quick scalps and bad for holding'},
  jupiter:{easy:'luck leans your way and optimism is actually earned', hard:'overconfidence is the trap since everything feels bigger than it is', merge:'expansion energy makes every move feel bigger than it is'},
  saturn:{easy:'discipline comes free, so your rules actually get followed', hard:'the market feels heavy and slow, and patience is the test', merge:'a cold, serious weight sits on your risk, so respect it'}
};

function ctx(f, seedRng){
  const n = f.natal, t = f.transit;
  return {
    sunSign: n.sun.sign, moonSign: n.moon.sign, risingSign: n.rising.sign,
    sunStyle: SUN_STYLE[n.sun.sign], tMoon: t.moon.sign, tMoonFeel: MOON_FEEL[f.moonEl], mood: MOOD[f.moonEl],
    natalMoonFeel: MOON_FEEL[({Aries:'fire',Leo:'fire',Sagittarius:'fire',Taurus:'earth',Virgo:'earth',Capricorn:'earth',Gemini:'air',Libra:'air',Aquarius:'air',Cancer:'water',Scorpio:'water',Pisces:'water'})[n.moon.sign]]
  };
}
const fill = (s, c) => s.replace(/\{(\w+)\}/g, (_, k) => c[k]);

function skyLines(f, c){
  const h = f.hits[0], out = [];
  if(h){
    const tr = h.transit === 'moon' ? 'the ' + c.tMoon + ' Moon' : 'transiting ' + P[h.transit];
    const np = h.natal === 'rising' ? 'your Rising' : 'your natal ' + P[h.natal];
    const eff = EFFECT[h.transit][h.tone];
    out.push(cap(tr) + ' ' + VERB[h.aspect] + ' ' + np + ' today, so ' + eff + '.');
    out.push('Today ' + tr + ' ' + VERB[h.aspect] + ' ' + np + ', which means ' + eff + '.');
    out.push('The big signal today: ' + tr + ' ' + VERB[h.aspect] + ' ' + np + ', so ' + eff + '.');
  } else {
    const ph = {new:'a fresh New Moon', waxing:'a building Moon', full:'a Full Moon', waning:'a fading Moon'}[f.phase];
    out.push('No loud aspect hits your chart today, so ' + ph + ' in ' + c.tMoon + ' sets the tone, and your ' + c.moonSign + ' Moon ' + c.natalMoonFeel + '.');
    out.push('It is a quiet sky for you, with ' + ph + ' in ' + c.tMoon + ' doing most of the talking while your ' + c.moonSign + ' Moon ' + c.natalMoonFeel + '.');
  }
  return out;
}
function pairsLines(f, c){
  if(f.mercuryRx) return [
    fill('Mercury is retrograde, so fresh launches hide mistakes, and coins that already have life are the safer room; your {sunSign} Sun {sunStyle}, which suits waiting.', c),
    fill('With Mercury retrograde, skip brand new pairs and stay with coins that already have life, since your {sunSign} Sun {sunStyle} and today rewards re-checking.', c)];
  return {
    new:[fill('Your {sunSign} Sun {sunStyle}, so a little gambling on fresh pairs is fair game today, as long as each ticket stays small.', c),
         fill('Fresh pairs are on the menu, since your {sunSign} Sun {sunStyle} and this sky gives that instinct some room.', c)],
    mix:[fill('Split it: your {sunSign} Sun {sunStyle}, so take one small swing at a new pair and park the rest in coins that already have life.', c),
         fill('Go half and half, because your {sunSign} Sun {sunStyle}, but the sky only half supports it: one fresh pair, the rest in established names.', c)],
    established:[fill('Skip brand new pairs and lean on established coins that already have life, since your {sunSign} Sun {sunStyle} and today rewards patience over speed.', c),
                 fill('Established coins beat fresh launches today, because your {sunSign} Sun {sunStyle} and the sky punishes anyone who arrives first and checks later.', c)]
  }[f.pairs];
}
function reasonDown(f, c){
  if(f.saturnHard) return 'Saturn is pressing on your chart';
  if(f.marsHard) return 'Mars is rattling your nerves';
  if(f.mercuryRx) return 'Mercury retrograde makes misreads likely';
  return {fire:'the ' + c.tMoon + ' Moon rushes decisions', earth:'the ' + c.tMoon + ' Moon wants proof the market will not give', air:'the ' + c.tMoon + ' Moon scatters your focus', water:'the ' + c.tMoon + ' Moon turns every wick emotional'}[f.moonEl];
}
function reasonUp(f, c){
  if(f.jupiterEasy) return 'Jupiter is backing your chart';
  return {fire:'the ' + c.tMoon + ' Moon gives you nerve', earth:'the ' + c.tMoon + ' Moon keeps you grounded', air:'the ' + c.tMoon + ' Moon sharpens your reads', water:'the ' + c.tMoon + ' Moon tunes your instincts'}[f.moonEl];
}
function sizeLines(f, c){
  return {
    up:['Size can step up a notch because ' + reasonUp(f, c) + ', but only with money you can lose.', 'You have permission to size up a little, since ' + reasonUp(f, c) + ', though never past what you can lose.'],
    normal:['Normal size is fine, no hero tickets, and ' + reasonUp(f, c) + ' enough to trust it.', 'Keep your usual size, because ' + reasonUp(f, c) + ', but nothing here justifies a hero ticket.'],
    down:['Size down, because ' + reasonDown(f, c) + ', and small tickets let you stay clear-headed.', 'Play smaller than usual, since ' + reasonDown(f, c) + ', and let the sizing do the protecting.'],
    tiny:['Stay tiny, because ' + reasonDown(f, c) + ', and one oversized bet costs more than any pump you miss.', 'Keep tickets tiny, since ' + reasonDown(f, c) + ', and treat survival as the win.']
  }[f.size];
}
function devLines(f, c){
  if(f.dev === 'yes') return [
    'Devving is genuinely live: ' + (f.creativeMoon ? 'the ' + c.tMoon + ' Moon loves a punchy idea, ' : '') + 'so if your concept is clean, tonight\'s window is real.',
    'A Pump.fun launch is worth a look tonight if the idea is already finished, since devving needs the same momentum this sky is giving you.'];
  if(f.dev === 'maybe') return [
    'Devving is possible but not urgent, so launch only if the idea already feels finished.',
    'Trading comes first, and devving only if a concept arrives complete rather than half-baked.'];
  return f.mercuryRx
    ? ['Leave devving for another day, since Mercury retrograde turns launches sloppy and trading is the cleaner play.', 'Trading beats devving today, because retrograde Mercury is brutal on launches, so keep the idea in your notes.']
    : ['Trading beats devving today, so keep the launch idea in your notes for a warmer sky.', 'Skip devving tonight, since a launch into this mood sits alone with no buyers, and trading is the better use of the day.'];
}
function playLines(f, c){
  return {
    in:['Stay in the trenches with an exit plan, because the day feels ' + c.mood + '.', 'Stay in the trenches but take profit when it shows, since the mood is ' + c.mood + '.'],
    light:['Stay in, but keep it light and leave early, because the mood is ' + c.mood + '.', 'Play it light and short, since the day feels ' + c.mood + ', and log off before midnight fomo.'],
    sit:['Honestly, sitting out is the strong play, because the mood is ' + c.mood + ' and this sky is not rewarding anyone.', 'Sit most of it out, peek once, and let others be exit liquidity, since the day feels ' + c.mood + '.']
  }[f.play];
}

function compose(f, variant, seed){
  const c = ctx(f);
  const pools = [skyLines(f, c), pairsLines(f, c), sizeLines(f, c), devLines(f, c), playLines(f, c)];
  let a = (seed >>> 0) + (variant + 1) * 0x9E3779B1;
  const r = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  let best = null, bd = 1e9;
  for(let i = 0; i < 80; i++){
    const text = pools.map(p => p[Math.floor(r() * p.length)]).join(' ');
    const d = Math.abs(wc(text) - 100);
    if(d < bd){ bd = d; best = text; }
    if(d <= 7) break;
  }
  return best;
}

/* Plain-text fact sheet for the LLM, so it writes from the real chart rather than inventing one. */
function factSheet(f){
  const n = f.natal, t = f.transit, L = [];
  const fmt = p => p.sign + ' ' + Math.floor(p.deg) + '°' + (p.rx ? ' Rx' : '');
  L.push('Natal: Sun ' + fmt(n.sun) + ', Moon ' + fmt(n.moon) + ', Rising ' + fmt(n.rising) + ', Mercury ' + fmt(n.mercury) + ', Venus ' + fmt(n.venus) + ', Mars ' + fmt(n.mars) + ', Jupiter ' + fmt(n.jupiter) + ', Saturn ' + fmt(n.saturn) + '.');
  L.push('Chart temperament: mostly ' + f.dominant + ' (' + Object.entries(f.count).map(([k, v]) => k + ' ' + v).join(', ') + ').');
  L.push('Today: Moon in ' + t.moon.sign + ' (' + f.phase + ' phase), Sun in ' + t.sun.sign + ', Mercury ' + t.mercury.sign + (t.mercury.rx ? ' RETROGRADE' : ' direct') + ', Venus ' + t.venus.sign + ', Mars ' + t.mars.sign + '.');
  const hs = f.hits.slice(0, 4).map(h => 'transiting ' + P[h.transit] + ' ' + h.aspect + ' natal ' + P[h.natal] + ' (orb ' + h.orb.toFixed(1) + '°)');
  L.push('Strongest transits to the birth chart today: ' + (hs.length ? hs.join('; ') : 'none, a quiet day') + '.');
  const lean = {
    pairs: {new:'lean toward gambling a little on new pairs', mix:'split: one small swing at a new pair, rest in established coins', established:'favor established coins that already have life over new pairs'}[f.pairs],
    size: {up:'sizing up a notch is supported', normal:'normal size', down:'size down', tiny:'stay tiny'}[f.size],
    dev: {yes:'devving (launching on Pump.fun) is favored', maybe:'devving is possible but not urgent', no:'trade rather than dev today'}[f.dev],
    play: {in:'stay in the trenches', light:'stay in but light and short', sit:'sitting out is the better play'}[f.play]
  };
  L.push('Verdict from the chart math (follow it, do not contradict it): ' + lean.pairs + '; ' + lean.size + '; ' + lean.dev + '; ' + lean.play + '. Rating: ' + f.rating + '/10.');
  return L.join('\n');
}

const api = {compose, factSheet, wc};
if(typeof module !== 'undefined' && module.exports) module.exports = api; else root.Reader = api;
})(typeof window !== 'undefined' ? window : globalThis);
