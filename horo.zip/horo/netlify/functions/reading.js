// LLM reading. Needs ANTHROPIC_API_KEY in Netlify env vars. Without it, returns 501 and the client uses its local generator.
const SYSTEM = `You are Horo: a human astrologer who also lives in the Solana trenches. Write the daily reading for one person from the fact sheet you are given.
Rules: ONE continuous paragraph of 90 to 110 words, no lists, no headings, no line breaks. Sound like a real astrologer talking to a friend, not a template or an astrology app. Use the actual placements and today's transits from the fact sheet, never invent any. Say how today's Moon and the strongest transit affect their trading mood. Clearly say: whether to gamble a little on new pairs or size into established coins that already have life; whether to play bigger or smaller sizes; trade vs devving (devving means launching a coin on Pump.fun or similar); stay in the trenches or sit out. Follow the verdict in the fact sheet. No financial advice, no specific coins, no guarantees, never say "revving". Then on a new line write exactly: Rating: X/10 using the rating in the fact sheet. Output nothing else.`;

const wc = s => s.trim().split(/\s+/).filter(Boolean).length;
const ok = out => {
  const m = out.trim().match(/^([\s\S]*?)\s*\n\s*Rating:\s*(\d{1,2})\/10\s*$/);
  if (!m) return false;
  const t = m[1].trim(), n = wc(t);
  return n >= 90 && n <= 110 && !/\n/.test(t) && !/^\s*([-*•]|\d+\.)\s/.test(t) && !/revving/i.test(t);
};

exports.handler = async (event) => {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return { statusCode: 501, body: JSON.stringify({ error: 'no key' }) };
  try {
    const { sheet, variant } = JSON.parse(event.body || '{}');
    if (!sheet || sheet.length > 3000) return { statusCode: 400, body: JSON.stringify({ error: 'bad input' }) };
    const user = `FACT SHEET:\n${sheet}\n\n(Variation ${variant || 0}: phrase it freshly.)`;
    for (let attempt = 0; attempt < 2; attempt++) {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 400, temperature: 1, system: SYSTEM, messages: [{ role: 'user', content: user }] })
      });
      if (!r.ok) break;
      const j = await r.json();
      const out = (j.content || []).filter(b => b.type === 'text').map(b => b.text).join('').trim();
      if (ok(out)) return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ reading: out }) };
    }
  } catch (e) {}
  return { statusCode: 502, body: JSON.stringify({ error: 'generation failed' }) };
};
