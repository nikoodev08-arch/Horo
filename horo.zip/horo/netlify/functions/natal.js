// Optional CORS proxy for CosmyDay, used only if the browser can't call it directly.
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'POST only' };
  try {
    const r = await fetch('https://api.cosmyday.com/natal', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: event.body
    });
    return { statusCode: r.status, headers: { 'Content-Type': 'application/json' }, body: await r.text() };
  } catch (e) { return { statusCode: 502, body: JSON.stringify({ error: 'upstream failed' }) }; }
};
