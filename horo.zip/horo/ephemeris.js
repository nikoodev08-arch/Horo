/* Horo ephemeris: natal chart + daily transits computed in the browser.
   Low-precision planetary theory (Schlyter / Meeus-style elements). Accurate to well under 1 degree for
   Sun, Moon and planets, which is enough to get signs right except within a degree or so of a sign edge. */
(function (root) {
'use strict';
const RAD = Math.PI / 180, DEG = 180 / Math.PI;
const n360 = a => ((a % 360) + 360) % 360;
const SIGNS = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
const ELEMENT = ['fire','earth','air','water'];                // Aries=fire, Taurus=earth, Gemini=air, Cancer=water...
const elementOf = lon => ELEMENT[Math.floor(n360(lon) / 30) % 4];
const signOf = lon => SIGNS[Math.floor(n360(lon) / 30)];

const jdFromMs = ms => ms / 86400000 + 2440587.5;
const dayNum = jd => jd - 2451543.5;                           // days since 1999-12-31 0h UT

function elements(name, d){
  switch(name){
    case 'sun':     return {N:0, i:0, w:282.9404+4.70935e-5*d, a:1, e:0.016709-1.151e-9*d, M:356.0470+0.9856002585*d};
    case 'moon':    return {N:125.1228-0.0529538083*d, i:5.1454, w:318.0634+0.1643573223*d, a:60.2666, e:0.054900, M:115.3654+13.0649929509*d};
    case 'mercury': return {N:48.3313+3.24587e-5*d, i:7.0047+5.00e-8*d, w:29.1241+1.01444e-5*d, a:0.387098, e:0.205635+5.59e-10*d, M:168.6562+4.0923344368*d};
    case 'venus':   return {N:76.6799+2.46590e-5*d, i:3.3946+2.75e-8*d, w:54.8910+1.38374e-5*d, a:0.723330, e:0.006773-1.302e-9*d, M:48.0052+1.6021302244*d};
    case 'mars':    return {N:49.5574+2.11081e-5*d, i:1.8497-1.78e-8*d, w:286.5016+2.92961e-5*d, a:1.523688, e:0.093405+2.516e-9*d, M:18.6021+0.5240207766*d};
    case 'jupiter': return {N:100.4542+2.76854e-5*d, i:1.3030-1.557e-7*d, w:273.8777+1.64505e-5*d, a:5.20256, e:0.048498+4.469e-9*d, M:19.8950+0.0830853001*d};
    case 'saturn':  return {N:113.6634+2.38980e-5*d, i:2.4886-1.081e-7*d, w:339.3939+2.97661e-5*d, a:9.55475, e:0.055546-9.499e-9*d, M:316.9670+0.0334442282*d};
    case 'uranus':  return {N:74.0005+1.3978e-5*d, i:0.7733+1.9e-8*d, w:96.6612+3.0565e-5*d, a:19.18171-1.55e-8*d, e:0.047318+7.45e-9*d, M:142.5905+0.011725806*d};
    case 'neptune': return {N:131.7806+3.0173e-5*d, i:1.7700-2.55e-7*d, w:272.8461-6.027e-6*d, a:30.05826+3.313e-8*d, e:0.008606+2.15e-9*d, M:260.2471+0.005995147*d};
  }
}
function orbit(o){
  const N = o.N*RAD, i = o.i*RAD, w = o.w*RAD, M = n360(o.M)*RAD, e = o.e, a = o.a;
  let E = M + e*Math.sin(M)*(1 + e*Math.cos(M));
  for(let k = 0; k < 12; k++){ const dE = (E - e*Math.sin(E) - M) / (1 - e*Math.cos(E)); E -= dE; if(Math.abs(dE) < 1e-10) break; }
  const xv = a*(Math.cos(E) - e), yv = a*Math.sqrt(1 - e*e)*Math.sin(E);
  const v = Math.atan2(yv, xv), r = Math.hypot(xv, yv), vw = v + w;
  return {
    x: r*(Math.cos(N)*Math.cos(vw) - Math.sin(N)*Math.sin(vw)*Math.cos(i)),
    y: r*(Math.sin(N)*Math.cos(vw) + Math.cos(N)*Math.sin(vw)*Math.cos(i)),
    z: r*Math.sin(vw)*Math.sin(i), r, vw
  };
}
const lonLat = p => ({lon: n360(Math.atan2(p.y, p.x)*DEG), lat: Math.atan2(p.z, Math.hypot(p.x, p.y))*DEG});
const sinD = a => Math.sin(a*RAD), cosD = a => Math.cos(a*RAD);

function sunGeo(d){
  const o = elements('sun', d), p = orbit(o);
  const lon = n360(p.vw*DEG);
  return {lon, r: p.r, x: p.r*Math.cos(lon*RAD), y: p.r*Math.sin(lon*RAD)};
}
function moonLon(d){
  const o = elements('moon', d), p = orbit(o), ll = lonLat(p);
  const s = elements('sun', d);
  const Ms = n360(s.M), Mm = n360(o.M), Ls = n360(s.M + s.w), Lm = n360(o.M + o.w + o.N);
  const D = Lm - Ls, F = Lm - o.N;
  const dl = -1.274*sinD(Mm-2*D) + 0.658*sinD(2*D) - 0.186*sinD(Ms) - 0.059*sinD(2*Mm-2*D) - 0.057*sinD(Mm-2*D+Ms)
           + 0.053*sinD(Mm+2*D) + 0.046*sinD(2*D-Ms) + 0.041*sinD(Mm-Ms) - 0.035*sinD(D) - 0.031*sinD(Mm+Ms)
           - 0.015*sinD(2*F-2*D) + 0.011*sinD(Mm-4*D);
  return n360(ll.lon + dl);
}
function planetLon(name, d){
  const o = elements(name, d), p = orbit(o);
  let {lon, lat} = lonLat(p);
  const Mj = n360(elements('jupiter', d).M), Msat = n360(elements('saturn', d).M), Mu = n360(elements('uranus', d).M);
  if(name === 'jupiter'){
    lon += -0.332*sinD(2*Mj-5*Msat-67.6) - 0.056*sinD(2*Mj-2*Msat+21) + 0.042*sinD(3*Mj-5*Msat+21)
         - 0.036*sinD(Mj-2*Msat) + 0.022*cosD(Mj-Msat) + 0.023*sinD(2*Mj-3*Msat+52) - 0.016*sinD(Mj-5*Msat-69);
  } else if(name === 'saturn'){
    lon += 0.812*sinD(2*Mj-5*Msat-67.6) - 0.229*cosD(2*Mj-4*Msat-2) + 0.119*sinD(Mj-2*Msat-3)
         + 0.046*sinD(2*Mj-6*Msat-69) + 0.014*sinD(Mj-3*Msat+32);
    lat += -0.020*cosD(2*Mj-4*Msat-2) + 0.018*sinD(2*Mj-6*Msat-49);
  } else if(name === 'uranus'){
    lon += 0.040*sinD(Msat-2*Mu+6) + 0.035*sinD(Msat-3*Mu+33) - 0.015*sinD(Mj-Mu+20);
  }
  const xh = p.r*cosD(lat)*cosD(lon), yh = p.r*cosD(lat)*sinD(lon);
  const s = sunGeo(d);
  return n360(Math.atan2(yh + s.y, xh + s.x)*DEG);
}
const BODIES = ['sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune'];
function bodyLon(name, d){
  if(name === 'sun') return sunGeo(d).lon;
  if(name === 'moon') return moonLon(d);
  return planetLon(name, d);
}
function wrap180(a){ a = n360(a); return a > 180 ? a - 360 : a; }
function positions(jd){
  const d = dayNum(jd), out = {};
  for(const b of BODIES){
    const lon = bodyLon(b, d);
    const speed = wrap180(bodyLon(b, d + 0.5) - bodyLon(b, d - 0.5));     // deg/day
    out[b] = {lon, sign: signOf(lon), deg: lon % 30, rx: b !== 'sun' && b !== 'moon' && speed < 0, speed};
  }
  return out;
}
function ascendant(jd, lat, lon){
  const T = (jd - 2451545) / 36525;
  const gmst = n360(280.46061837 + 360.98564736629*(jd - 2451545) + 0.000387933*T*T);
  const ramc = n360(gmst + lon)*RAD, eps = (23.439291 - 0.0130042*T)*RAD;
  return n360(Math.atan2(Math.cos(ramc), -(Math.sin(ramc)*Math.cos(eps) + Math.tan(lat*RAD)*Math.sin(eps)))*DEG);
}

/* ---------- time zones ---------- */
function tzOffsetMin(ms, tz){
  const p = {};
  new Intl.DateTimeFormat('en-US', {timeZone: tz, hourCycle: 'h23', year:'numeric', month:'numeric', day:'numeric', hour:'numeric', minute:'numeric', second:'numeric'})
    .formatToParts(new Date(ms)).forEach(x => p[x.type] = +x.value);
  return (Date.UTC(p.year, p.month-1, p.day, p.hour, p.minute, p.second) - Math.floor(ms/1000)*1000) / 60000;
}
/* Local birth time -> UTC ms. tz = IANA name. Without one, falls back to solar time from longitude (flagged approx). */
function utcFromLocal(Y, M, D, h, m, tz, lon){
  const naive = Date.UTC(Y, M-1, D, h, m);
  if(tz){
    try{
      let t = naive - tzOffsetMin(naive, tz)*60000;
      t = naive - tzOffsetMin(t, tz)*60000;
      return {ms: t, approx: false};
    }catch(_){}
  }
  return {ms: naive - Math.round(lon/15)*3600000, approx: true};
}

/* ---------- natal chart ---------- */
function natalChart({year, month, day, hour, minute, lat, lon, tz}){
  const u = utcFromLocal(year, month, day, hour, minute, tz, lon);
  const jd = jdFromMs(u.ms), pos = positions(jd);
  const asc = ascendant(jd, lat, lon);
  pos.rising = {lon: asc, sign: signOf(asc), deg: asc % 30, rx: false};
  return {chart: pos, tzApprox: u.approx, utcMs: u.ms};
}

/* ---------- aspects & daily facts ---------- */
const ASPECTS = [{name:'conjunction', a:0, tone:'merge'}, {name:'sextile', a:60, tone:'easy'}, {name:'square', a:90, tone:'hard'},
                 {name:'trine', a:120, tone:'easy'}, {name:'opposition', a:180, tone:'hard'}];
function aspectBetween(l1, l2, orb){
  let d = Math.abs(n360(l1 - l2)); if(d > 180) d = 360 - d;
  for(const A of ASPECTS){ const off = Math.abs(d - A.a); if(off <= orb) return {name:A.name, tone:A.tone, orb:off}; }
  return null;
}
const ORB = {moon:5, sun:5, mercury:4, venus:4, mars:4, jupiter:3, saturn:3};
const NATAL_POINTS = ['sun','moon','rising','mercury','venus','mars','jupiter','saturn'];
const NATAL_WEIGHT = {sun:1.2, moon:1.2, rising:1.1, mercury:.8, venus:.8, mars:.9, jupiter:.7, saturn:.8};
const TRANSIT_WEIGHT = {moon:1.0, sun:.8, mercury:.7, venus:.8, mars:1.1, jupiter:1.0, saturn:1.0};

function lunarPhase(sunLon, moonLon){
  const e = n360(moonLon - sunLon);
  if(e < 22 || e > 338) return 'new';
  if(e < 158) return 'waxing';
  if(e < 202) return 'full';
  return 'waning';
}

function analyze(natal, nowMs, opts){
  opts = opts || {};
  const tr = positions(jdFromMs(nowMs));
  const hits = [];
  for(const tb of Object.keys(TRANSIT_WEIGHT)){
    for(const np of NATAL_POINTS){
      if(opts.unknownTime && (np === 'rising' || (np === 'moon' && tb !== 'moon' && false))) continue;
      const nat = natal[np]; if(!nat) continue;
      const asp = aspectBetween(tr[tb].lon, nat.lon, ORB[tb]);
      if(!asp) continue;
      const tight = 1 - asp.orb / ORB[tb];
      hits.push({transit: tb, natal: np, aspect: asp.name, tone: asp.tone, orb: asp.orb,
                 score: tight * TRANSIT_WEIGHT[tb] * NATAL_WEIGHT[np] * (tb === 'moon' ? 1 : 1.15)});
    }
  }
  hits.sort((a, b) => b.score - a.score);

  // natal temperament: how fire/air (go) vs earth/water (hold) the chart runs
  const pts = ['sun','moon','mercury','venus','mars','jupiter','saturn'].concat(opts.unknownTime ? [] : ['rising']);
  const count = {fire:0, earth:0, air:0, water:0};
  pts.forEach(p => count[elementOf(natal[p].lon)]++);
  const dominant = Object.keys(count).sort((a, b) => count[b] - count[a])[0];
  const temperament = (count.fire + count.air - count.earth - count.water) / pts.length;   // -1..1

  const phase = lunarPhase(tr.sun.lon, tr.moon.lon);
  const moonEl = elementOf(tr.moon.lon);

  // ---- scoring: positive = leans bold, negative = leans careful ----
  let R = temperament * 1.0;
  R += {fire:1.0, air:.5, water:-.2, earth:-.7}[moonEl];
  R += {new:.4, waxing:.3, full:-.2, waning:-.3}[phase];
  if(tr.mercury.rx) R -= 1.0;
  const drivers = [];
  for(const h of hits.slice(0, 4)){
    const w = Math.min(1, h.score * 1.4 + .35);
    let v = 0;
    if(h.transit === 'mars')    v = h.tone === 'easy' ? 1.0 : h.tone === 'hard' ? -1.0 : .4;
    if(h.transit === 'jupiter') v = h.tone === 'hard' ? -.2 : 1.2;
    if(h.transit === 'saturn')  v = h.tone === 'easy' ? .3 : -1.3;
    if(h.transit === 'venus')   v = h.tone === 'hard' ? -.5 : .5;
    if(h.transit === 'sun')     v = h.tone === 'hard' ? -.3 : .4;
    if(h.transit === 'mercury') v = h.tone === 'hard' ? -.4 : .3;
    if(h.transit === 'moon')    v = h.tone === 'hard' ? -.7 : h.tone === 'easy' ? .7 : .3;
    R += v * w;
  }
  const saturnHard = hits.some(h => h.transit === 'saturn' && h.tone !== 'easy');
  const marsHard = hits.some(h => h.transit === 'mars' && h.tone === 'hard');
  const jupiterEasy = hits.some(h => h.transit === 'jupiter' && h.tone !== 'hard');
  const mercuryRx = tr.mercury.rx;

  // ---- decisions ----
  let pairs;                                   // 'new' | 'mix' | 'established'
  if(mercuryRx || saturnHard || R < 0) pairs = 'established';
  else if(R >= 1.6) pairs = 'new';
  else pairs = 'mix';
  if(pairs === 'new' && marsHard) pairs = 'mix';

  let size;                                    // 'up' | 'normal' | 'down' | 'tiny'
  if(R >= 2.4 && !saturnHard && !marsHard) size = 'up';
  else if(R >= 0.9) size = 'normal';
  else if(R >= -0.5) size = 'down';
  else size = 'tiny';

  const creativeMoon = ['Gemini','Leo','Sagittarius','Aquarius'].includes(tr.moon.sign);
  let dev;                                     // 'yes' | 'maybe' | 'no'
  if(mercuryRx || R < 1.2 || saturnHard) dev = 'no';
  else if(R >= 2 && (creativeMoon || phase === 'new' || jupiterEasy)) dev = 'yes';
  else dev = 'maybe';

  const play = R < -1.4 ? 'sit' : R < 0 ? 'light' : 'in';
  const rating = Math.max(1, Math.min(10, Math.round(5.5 + R * 1.15)));   // how good a day the chart says a trader will have

  return {transit: tr, hits, natal, count, dominant, temperament, phase, moonEl, R, rating,
          pairs, size, dev, play, mercuryRx, saturnHard, marsHard, jupiterEasy, creativeMoon};
}

const api = {SIGNS, signOf, elementOf, jdFromMs, positions, ascendant, utcFromLocal, tzOffsetMin, natalChart, analyze, aspectBetween, lunarPhase};
if(typeof module !== 'undefined' && module.exports) module.exports = api; else root.Astro = api;
})(typeof window !== 'undefined' ? window : globalThis);
