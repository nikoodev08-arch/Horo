# Horo
Birth chart for the Solana trenches. Enter birth date, time and place, get one ~100 word trench reading for the next 24h plus `Rating: X/10`.
**Entertainment only. Not financial advice.**

## What's wired
- **Natal chart is computed in the browser** (`ephemeris.js`): Sun, Moon, Mercury through Neptune, retrograde flags and the Ascendant, for any date, time and place. No API needed. Validated against the J2000 reference positions, the 2024-04-08 eclipse, known retrograde periods and the Tbilisi test chart (Sun Sag, Moon Cap, Mercury Scorp, Mars Libra, Jupiter Gem Rx, Saturn Tau Rx, Leo rising).
- **Today's sky** is computed the same way: transiting Moon sign and phase, Mercury retrograde, and transits to the birth chart (conjunction, sextile, square, trine, opposition) with orbs.
- **Reading logic** (`reader.js`): a scoring pass turns natal temperament + today's Moon + the strongest transits into a verdict (new pairs vs established coins, size up/normal/down/tiny, trading vs devving, play or sit out, rating). The local writer phrases it as 90-110 words; with an LLM available, the same fact sheet and verdict go to the model so the prose reads like a human astrologer.
- Place → lat/lon: Nominatim (debounced autocomplete) with a built-in list of 175 big cities as offline fallback. Birth time zone comes from the city list or `tz-lookup` (CDN), converted with the browser's historical tz database (DST handled). If neither is available the zone is estimated from longitude and the page says so.
- CosmyDay: optional, off by default (`USE_COSMYDAY` in `app.js`); the local engine is the source of truth.
- Reading writer: LLM via `/api/reading` (Netlify function, needs `ANTHROPIC_API_KEY`), else the local writer. Output that breaks the rules (word count, list, "revving") is rejected and replaced.
- Date: day / month / year dropdowns. Unknown birth time → 12:00 local + accuracy note. Shareable card, download image, copy reading, reduced-motion support. One reading per chart (no regenerate).

## Run locally
Static only (local generator, direct API calls): `python3 -m http.server 8000` then open http://localhost:8000
With the LLM + proxy: `npm i -g netlify-cli`, `export ANTHROPIC_API_KEY=...`, `netlify dev`

## Deploy free (Netlify)
1. Push this folder to GitHub, then Netlify → Add new site → Import from Git. No build command, publish dir `.`
2. Site settings → Environment variables: `ANTHROPIC_API_KEY` (optional; `ANTHROPIC_MODEL` to override)
3. Deploy. Cloudflare Pages / Vercel also work as static hosts (local generator only, unless you port the two functions).

## Check first
Enter any birth date, time and place after deploy; "Download image" saves a 1080x1350 PNG of the card. Quick sanity check: 28 Nov 2000, 23:00, Tbilisi should give Sun Sagittarius, Moon Capricorn, Leo rising.
